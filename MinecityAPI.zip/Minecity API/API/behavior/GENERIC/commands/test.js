Bridge.register(class Command {
	static command_name = 'example'
	onApply() {}
	onPropose() {}
})